﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Fuzzie
{
    class FuzzieNumber : IComparable
    {
        public int Module { get; }
        public int Alpha { get; }
        public int Beta { get; }

        public FuzzieNumber(int module, int alpha, int beta)
        {
            Module = module;
            Alpha = alpha;
            Beta = beta;
        }

        public static FuzzieNumber operator +(FuzzieNumber a, FuzzieNumber b) =>
            new (a.Module + b.Module, a.Alpha + b.Alpha, a.Beta + b.Beta);

        public static FuzzieNumber operator -(FuzzieNumber a, FuzzieNumber b) =>
            new (a.Module - b.Module, a.Alpha + b.Beta, a.Beta + b.Alpha);

        public static FuzzieNumber operator *(FuzzieNumber a, FuzzieNumber b) =>
            new (a.Module * b.Module, a.Module * a.Alpha + b.Module * b.Beta, a.Module * a.Beta + b.Module * b.Alpha);

        public static FuzzieNumber operator /(FuzzieNumber a, FuzzieNumber b) =>
            a * Invert(b);

        public static FuzzieNumber Invert(FuzzieNumber a) =>
            new FuzzieNumber(1 / a.Module, a.Beta, a.Alpha / a.Module / a.Module);
            
        public static bool operator >(FuzzieNumber a, FuzzieNumber b) => a.CompareTo(b) == 1;
        public static bool operator <(FuzzieNumber a, FuzzieNumber b) => a.CompareTo(b) == -1;
        public static bool operator ==(FuzzieNumber a, FuzzieNumber b) => a.CompareTo(b) == 0;
        public static bool operator !=(FuzzieNumber a, FuzzieNumber b) => a.CompareTo(b) != 0;


        public int CompareTo(object n)
        {
            return 0;
        }
    }
}
