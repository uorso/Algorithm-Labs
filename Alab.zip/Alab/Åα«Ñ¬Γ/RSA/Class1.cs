﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace RSA
{
    public class RsaEncryptor
    {
        private int _e;
        private long _n;
        private Func<char, long> _charEncryption;

        public RsaEncryptor(Tuple<int, long> openKey)
        {
            _e = openKey.Item1;
            _n = openKey.Item2;
        }

        public long[] EncryptMassage(Tuple<int, long> openKey, string massage)
        {
            var code = new MyBigInt();
            var e = new MyBigInt(1);
            foreach (var chr in massage)
            {
                code += e * 
            }
            return Encoding.GetEncoding(1251).GetBytes(massage)
                .Select(b => (long)Math.Pow(b, openKey.Item1) % openKey.Item2).ToArray();
        }

    }

    public class RsaDecryptor
    {
        private int _e;
        private MyBigInt _p;
        private MyBigInt _q;
        public Tuple<int, long> OpenKey => Tuple.Create(_e, _p * _q);
        public string Decrypt(MyBigInt encryptedMassage)
        {
            var n = _p * _q;
            var d = new MyBigInt(_e).FindModuloInverseElement(_p * _q);
            var decryptedMassage = encryptedMassage
            // 1251 - Кодировка ASCII
            return Encoding.GetEncoding(1251).GetString(encryptedMassage.Digits
                .Select(b => (byte)(Math.Pow(b, d) % n)).ToArray());
        }
    }
}
