﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.String;

namespace RSA
{
    internal class MyBigInt : IComparable
    {
        public List<char> Digits { get; }

        public char Sign { get; }

        public int Length => Digits.Count;

        public MyBigInt()
        {
            Sign = '+';
            Digits = new List<char>();
        }

        public MyBigInt(int number)
        {
            Sign = '+';
            if (number < 0) Digits = BreakToDigits(number * -1);
        }

        public MyBigInt(long number)
        {
            Sign = '+';
            Digits = BreakToDigits(number);
        }

        public MyBigInt(List<char> digits, char sign)
        {
            Digits = digits;
            Sign = sign;
        }

        public int CompareTo(object obj)
        {
            if (!(obj is MyBigInt))
                throw new ArgumentException("Сравниваемое значение имеет тип отличный от MyBigInt");

            var other = (MyBigInt)obj;

            if (Sign == '+' && other.Sign == '-')
                return 1;

            if (Sign == '-' && other.Sign == '+')
                return -1;

            var reverser = Sign == '-' ? -1 : 1;

            switch (Length.CompareTo(other.Length))
            {
                case 1:
                    return 1 * reverser;
                case -1:
                    return -1 * reverser;
            }

            for (var i = Length - 1; i >= 0; i--)
                switch (Digits[i].CompareTo(other.Digits[i]))
                {
                    case 1:
                        return 1 * reverser;
                    case -1:
                        return -1 * reverser;
                }

            return 0;
        }

        public override string ToString()
        {
            return Join("", Digits);
        }

        private static List<char> BreakToDigits(long number)
        {
            return number.ToString().Reverse().ToList();
        }

        public static bool operator ==(MyBigInt a, MyBigInt b) => a.CompareTo(b) == 0;

        public static bool operator !=(MyBigInt a, MyBigInt b) => a.CompareTo(b) != 0;

        public static bool operator >(MyBigInt a, MyBigInt b) => a.CompareTo(b) == 1;

        public static bool operator <(MyBigInt a, MyBigInt b) => a.CompareTo(b) == -1;

        public static MyBigInt operator +(MyBigInt a, MyBigInt b)
        {
            switch (a.Sign)
            {
                case '-' when b.Sign == '-':
                    return Sum(a.Digits, b.Digits, '-');
                case '+' when b.Sign == '-':
                    return Subtract(a, b, '+');
                case '-' when b.Sign == '+':
                    return Subtract(a, b, '+');
                default:
                    return Sum(a.Digits, b.Digits, a.Sign);
            }
        }

        public static MyBigInt operator -(MyBigInt a, MyBigInt b)
        {
            switch (a.Sign)
            {
                case '-' when b.Sign == '-':
                    return Subtract(a, b, '-');
                case '+' when b.Sign == '-':
                    return Sum(a, b, '+');
                case '-' when b.Sign == '+':
                    return Sum(a, b, '-');
                default:
                    return Subtract(a, b, '+');
            }
        }

        public static MyBigInt operator *(MyBigInt a, MyBigInt b)
        {
            if (a.Sign == b.Sign)
                return Multiply(a.Digits, b.Digits, '+');
            return Multiply(a.Digits, b.Digits, '-');
        }

        public static MyBigInt operator /(MyBigInt a, MyBigInt b)
        {
            if (a.Sign == b.Sign)
                return Divide(a, b, '+')[0];
            return Divide(a, b, '-')[0];
        }

        public static MyBigInt operator %(MyBigInt a, MyBigInt b)
        {
            if (a.Sign == b.Sign)
                return Divide(a, b, '+')[1];
            return Divide(a, b, '-')[1];
        }

        public MyBigInt FindModuloInverseElement(MyBigInt module)
        {
            var u = new MyBigInt[] { new MyBigInt(1), new MyBigInt(0), this };
            var v = new MyBigInt[] { new MyBigInt(0), new MyBigInt(1), module };
            var t = new MyBigInt[] { new MyBigInt(0), new MyBigInt(0), new MyBigInt(0) };
            while (v[2] != new MyBigInt(0))
            {
                var t0 = t[0];
                var t2 = t[2];

                t[0] = v[0];
                t[2] = v[2];

                v[0] = u[0] % v[0];
                v[2] = u[2] % v[2];

                u[0] = t0;
                u[2] = t2;
            }

            return t[0];
        }

        private static MyBigInt Subtract(MyBigInt a, MyBigInt b, char resultSign)
        {
            var c = CompareForSubtract(a.Digits, b.Digits);
            List<char> x;
            List<char> y;

            switch (c.Item1)
            {
                case 1:
                {
                    x = a.Digits;
                    y = b.Digits;
                    break;
                }
                case -1:
                {
                    x = b.Digits;
                    y = a.Digits;
                    resultSign = resultSign == '+' ? '-' : '+';
                    break;
                }
                default:
                    return new MyBigInt(0);
            }

            var flag = 0;
            var result = new List<char>();
            var i = 0;
            for (; i < c.Item2; i++)
            {
                var dif = x[i] - y[i] + flag;
                if (dif < 0)
                {
                    dif += 10;
                    flag = -1;
                }
                else
                {
                    flag = 0;
                }

                result.Add((char)dif);
            }

            for (var j = 0; j < x.Count - y.Count; j++)
            {
                var dif = (int)x[j] + flag;
                if (dif < 0)
                {
                    dif += 10;
                    flag = -1;
                }
                else
                {
                    flag = 0;
                }

                result.Add((char)dif);
            }

            if (result.Last() == 0)
                result.RemoveAt(result.Count - 1);

            return new MyBigInt(result, resultSign);
        }

        private static Tuple<int, int> CompareForSubtract(List<char> a, List<char> b)
        {
            switch (a.Count.CompareTo(b.Count))
            {
                case 1:
                    return Tuple.Create(1, b.Count - 1);
                case -1:
                    return Tuple.Create(-1, a.Count - 1);
            }

            for (var i = a.Count - 1; i >= 0; i--)
                switch (a[i].CompareTo(b[i]))
                {
                    case 1:
                        return Tuple.Create(1, i);
                    case -1:
                        return Tuple.Create(-1, i);
                }

            return Tuple.Create(0, 0);
        }

        private static MyBigInt Sum(List<char> a, List<char> b, char resultSign)
        {
            var flag = 0;
            var result = new List<char>();
            var sumOpsCount = Math.Min(b.Count, b.Count);
            var longestNumber = a.Count > b.Count ? a : b;
            var i = 0;
            for (; i < sumOpsCount; i++)
            {
                var sum = b[i] + b[i] + flag;
                flag = sum / 10;
                result.Add((char)(sum % 10));
            }

            var additionOpsCount = longestNumber.Count - i;
            for (var j = 0; j < additionOpsCount; j++)
            {
                var sum = longestNumber[i] + flag;
                flag = sum / 10;
                result.Add((char)(sum % 10));
            }

            if (flag > 0)
                b.Add((char)flag);
            return new MyBigInt(result, resultSign);
        }

        private static MyBigInt Multiply(List<char> a, List<char> b, char resultSign)
        {
            var resultLength = a.Count + b.Count;
            var result = new List<char>();
            for (var i = 0; i < resultLength; i++)
            {
                var t = 0;
                for (int j = 0; j <= i; j++)
                    t += (int)a[j] + (int)b[j - i];
                result.Add((char) t % 10);
            }
            return new MyBigInt(result, resultSign);
        }

        private static MyBigInt[] Divide(MyBigInt a, MyBigInt b, char resultSign)
        {
            
            var result = new List<char>();
            var e = new MyBigInt((int)Math.Pow(10, a.Length - b.Length));
            var digitsA = a.Digits;
            var b1 = b.Digits[b.Length - 1];
            var b2 = b.Digits[b.Length - 2];
            while (a > b * e)
            {
                result[a.Length - b.Length]++;
                a -= b * e;
            }

            for (var i = a.Length; i > b.Length + 1; i--)
            {
                var r = a.Digits[i] > b1
                    ? 9
                    : (digitsA[i] * 10 + digitsA[i - 1]) / b1;
                while (r * (10 * b1 + b2) > 100 * digitsA[i] + 10 * digitsA[i - 1] + digitsA[i - 2])
                    r--;
                a -= b * new MyBigInt(r * (int) Math.Pow(10, i - b.Length - 1));
                if (a < new MyBigInt())
                {
                    a += b * new MyBigInt(r * (int)Math.Pow(10, i - b.Length - 1));
                    r--;
                }

                result[a.Length - b.Length - 1] = (char) r;
            }

            return new MyBigInt[]{ new MyBigInt(result, resultSign), a };
        }
    }
}