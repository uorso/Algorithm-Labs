﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Xml;
using System.Collections.Generic;
namespace Lab1
{
    public enum ProgressionType
    {
        Geometrical,
        Arithmetical
    }

    public class Experiment
    {
        public ProgressionType ProgressionType { get; }
        public int InitialLength { get; }
        public int SelectionCount { get; }
        public int Difference { get; }
        public int SelectionSize { get; }
        public Func<int, int> NewLengthCalculator { get; }

        public Experiment(ProgressionType progressionType)
        {
            var dataFromNodes = ReadExperimentSettings(FindExperiment(progressionType).ChildNodes);
            ProgressionType = progressionType;
            InitialLength = dataFromNodes[0];
            SelectionCount = dataFromNodes[1];
            Difference = dataFromNodes[2];
            SelectionSize = dataFromNodes[3];
            NewLengthCalculator = GetProgressionFunc(progressionType, Difference);
        }

        public Func<int, int> GetProgressionFunc(ProgressionType progressionType, int difference)
        {
            switch (progressionType)
            {
                case ProgressionType.Geometrical:
                    return b => b * difference;
                case ProgressionType.Arithmetical:
                    return a => a + difference;
                default:
                    throw new InvalidEnumArgumentException();
            }
        }

        private static XmlNode FindExperiment(ProgressionType progressionType)
        {
            var xmlDoc = new XmlDocument();
            xmlDoc.Load(
                @"D:\Пользовательские файлы\Документы\Рабочие документы\Программирование\Проекты C#\Alab\Alab\ExperimentPlan.xml");
            var plan = xmlDoc.DocumentElement;
            foreach (XmlNode experiment in plan)
                if (int.Parse(experiment.Attributes.GetNamedItem("progressionTypeCode").Value) == (int)progressionType)
                    return experiment;
            return null;
        }

        public static int[] ReadExperimentSettings(XmlNodeList experiment)
        {
            var result = new int[4];
            foreach (XmlNode d in experiment)
                switch (d.Name)
                {
                    case "initialLength":
                        result[0] = int.Parse(d.InnerText);
                        break;
                    case "countOfSelections":
                        result[1] = int.Parse(d.InnerText);
                        break;
                    case "difference":
                        result[2] = int.Parse(d.InnerText);
                        break;
                    case "selectionSize":
                        result[3] = int.Parse(d.InnerText);
                        break;
                }

            return result;
        }

        public Dictionary<int, long[]> GetExperimentResult()
        {
            var currentArrayLength = InitialLength;
            var result = new Dictionary<int, long[]>();
            for (var i = 0; i < SelectionCount; i++)
            {
                result[currentArrayLength] = Enumerable.Range(0, SelectionSize)
                    .Select(n => GetOperationCount(0, 50, currentArrayLength))
                    .ToArray();
                currentArrayLength = NewLengthCalculator(currentArrayLength);
            }

            return result;
        }

        public static long GetOperationCount(int minElement, int maxElement, int arrayLength)
        {
            var operationCount = 0;
            Sort.MergeSort(CreateRandomArray(minElement, maxElement, arrayLength), ref operationCount);
            return operationCount;
        }

        public static int[] CreateRandomArray(int minElement, int maxElement, int length)
        {
            var rnd = new Random();
            return Enumerable.Range(0, length).Select(n => rnd.Next(minElement, maxElement)).ToArray();
        }
    }
}