﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Lab1
{
    public static class Sort
    {
        public static int[] MergeSort(int[] input, ref int insertionOperationCount)
        {
            if (input.Length < 2)
                return input;
            var mid = input.Length / 2;
            var leftHalf = MergeSort(input[..mid], ref insertionOperationCount);
            var rightHalf = MergeSort(input[mid..], ref insertionOperationCount);
            return Merge(leftHalf, rightHalf, ref insertionOperationCount);
        }

        private static int[] Merge(int[] leftHalf, int[] rightHalf, ref int compersionOperationCount)
        {
            var li = 0;
            var ri = 0;
            var lLen = leftHalf.Length;
            var rLen = rightHalf.Length;
            var currentL = leftHalf[li];
            var currentR = rightHalf[ri];
            var allLeftHalfUsed = false;
            var allRightHalfUsed = false;
            var result = new int[lLen + rLen];
            var currentResultIndex = 0;

            while (!allLeftHalfUsed && !allRightHalfUsed)
                if (currentL < currentR)
                    currentL = InsertValueAndMoveIndexes(ref li, ref currentResultIndex, currentL, ref allLeftHalfUsed, leftHalf, result);
                else
                    currentR = InsertValueAndMoveIndexes(ref ri, ref currentResultIndex, currentR, ref allRightHalfUsed, rightHalf, result);

            compersionOperationCount += currentResultIndex;
            for (; li < lLen; li++)
                result[currentResultIndex++] = leftHalf[li];
            
            for (; ri < rLen; ri++)
                result[currentResultIndex++] = rightHalf[ri];
            
            return result.ToArray();
        }

        private static int InsertValueAndMoveIndexes ( ref int outputIndex, ref int inputIndex, int insertingValue, ref bool areAllUsed, int[] outputArray, int[] inputArray)
        {
            inputArray[inputIndex++] = insertingValue;
            if (outputIndex + 1 != outputArray.Length) 
                return outputArray[++outputIndex];
            outputIndex++;
            areAllUsed = true;
            return insertingValue;
        }
    }
}
