﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Runtime.InteropServices;
using System.Text;
using System.Linq;

namespace Lab1
{
    нарифметика целочисленных значеный произвольной длинны
    public class Program
    {
        public static void Main(string[] arg)
        {
            Console.WriteLine("Выполнить эксперимент перед началом программы?: yes/no");
            if (Console.ReadLine() == "yes")
            {
                Console.WriteLine("Выбирите тип прогрессии");
                ProgressionType progressionType;
                switch (Console.ReadLine())
                {
                    case "геометрическая":
                        ConsoleApp.PrintExperimentResult(new Experiment(ProgressionType.Geometrical));
                        break;
                    case "арифметическая":
                        ConsoleApp.PrintExperimentResult(new Experiment(ProgressionType.Arithmetical));
                        break;
                }

                Console.WriteLine();
            }

            Console.WriteLine();
            Console.WriteLine("Введите целые числа через пробел для сортировки:");
            try
            {
                var operationCount = 0;
                var sorted = Sort.MergeSort(Console.ReadLine().Split(" ").Select(int.Parse).ToArray(), ref operationCount);
                Console.WriteLine("Отсортированный массив: " + string.Join(" ", sorted));
            }
            catch (System.FormatException)
            {
                Console.WriteLine("Неправильный формат ввода.");
            }

        }
    }

    public class ConsoleApp
    {
        public static void PrintExperimentResult(Experiment e)
        {
            Console.WriteLine($"Тип прогрессии: {e.ProgressionType}, количество выборок: {e.SelectionCount}, размер выборки: {e.SelectionSize}\n");
            var result = e.GetExperimentResult();
            var i = 1;
            foreach (var kv in result)
            {
                var j = 1;
                Console.WriteLine($"Выборка №{i++}, длина массива: {kv.Key}");
                foreach (var opCount in kv.Value)
                    Console.WriteLine($"Массив №{j++}, количество операций: {opCount}");
                Console.WriteLine();
            }
        }
    }
}
